﻿using System;

namespace Assigntment_1
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            if (args is null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            Recipes recipe = new Recipes();
            Console.WriteLine("Enter details for recipe:");
            Console.Write("Enter number of ingredients :");
            int numIngredients = int.Parse(Console.ReadLine());

            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"\nIngredients {i + 1}");
                Console.Write("Name :");
                string name = Console.ReadLine();
                Console.Write("Quantity =");
                double quantity = double.Parse(Console.ReadLine());
                Console.Write("Unit of measurement :");
                string unit = Console.ReadLine();

                recipe.AddIngredient(name, quantity, unit);
            }
            Console.WriteLine("\nNumber of steps:");
            int v = int.Parse(Console.ReadLine());
            int numSteps = v;

            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"\nSteps {i + 1}:");
                Console.Write("Descriptions :");
                string description = Console.ReadLine();

                recipe.AddStep(description);
            }
            Console.WriteLine("\nRecipe :");
            recipe.DisplayRecipe();

            while (true)
            {
                Console.WriteLine("\nOptions:");
                Console.WriteLine(" 1. Scale the recipe");
                Console.WriteLine("2. Reset the quantities to original values");
                Console.WriteLine("3. Clear all data and enter a new recipe");
                Console.WriteLine("4. Exit to home page ");

                Console.WriteLine("enter your choice :");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter scale factor (1.5 for half, 2.5 for double, 3.5 for triple)");
                        double factor = double.Parse(Console.ReadLine());
                        recipe.ScaleRecipe(factor);
                        Console.WriteLine("\nScaled Recipe");
                        recipe.DisplayRecipe();
                        break;

                    case 2:
                        recipe.ResetQuantities();
                        Console.WriteLine("\nQuantities rest to original values :");
                        recipe.DisplayRecipe();
                        break;

                    case 3:
                        recipe.ClearRecipe(recipe.GetSteps());
                        Console.WriteLine("\ndata cleared...Insert new recipe :");
                        break;

                    case 4:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Inavlid request");
                        break;
                }
            }
        }
    }
}
