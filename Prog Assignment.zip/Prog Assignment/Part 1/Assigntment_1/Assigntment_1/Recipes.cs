﻿using System;
using System.Collections.Generic;

namespace Assigntment_1
{
    public class Recipes
    {
        private int i;

        public List<Ingredients> Ingredients { get; set; } = new List<Ingredients>();
        public List<Steps> Steps { get; private set; }
        public bool I { get; private set; }

        public Recipes()
        {
            Ingredients = new List<Ingredients>();
            Steps = new List<Steps>();


        }
        public void AddIngredient(string name, double quantity, string unit)
        {
            Ingredients.Add(new Ingredients(name, quantity, unit));

        }
        public void AddStep(string description)
        {
            Steps.Add(new Steps(description));
        }

        public List<Steps> GetSteps()
        {
            return Steps;
        }

        public void ClearRecipe(List<Steps> steps)
        {
            if (steps is null)
            {
                throw new ArgumentNullException(nameof(steps));
            }

            Ingredients.Clear();


        }
        public void ScaleRecipe(double factor)
        {
            foreach (Ingredients ingredient in Ingredients)
            {
                ingredient.Quantity = factor;

            }
        }
        public void DisplayRecipe()
        {
            Console.WriteLine("Ingredients");
            foreach (Ingredients ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Name} {ingredient.Unit} of {ingredient.Name}");
            }


            {

            }


            {
                i = 0;
                string value = $" {Steps[i].Description}";
                Console.WriteLine(value);

            }
        }

        internal void ResetQuantities()
        {
            throw new NotImplementedException();
        }





    }
}
